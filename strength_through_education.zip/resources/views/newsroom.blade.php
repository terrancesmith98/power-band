@extends('layouts/app')
@section('title', 'STE | Newsroom')

@section('content')
<div class="tile tile-dark-blue">
    <h1 class="text-center">News Room</h1>
    <p class="lead text-center">content</p>
</div>
    
@endsection