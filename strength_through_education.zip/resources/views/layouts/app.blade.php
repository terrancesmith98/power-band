<x-head></x-head>
<body>
    <div id="app">
        <x-navbar></x-navbar>
            @yield('content')
    </div>
</body>
<x-footer></x-footer>
</html>
