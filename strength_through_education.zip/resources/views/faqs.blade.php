@extends('layouts/app')
@section('title', 'STE | FAQs')

@section('content')
<div class="tile tile-dark-blue">
    <h1 class="text-center">FAQs</h1>
    <p class="lead text-center">content</p>
</div>
    
@endsection