@extends('layouts/app')
@section('title', 'STE | Who We Are')

@section('content')
<div class="tile tile-dark-blue">
    <h1 class="text-center">Who We Are</h1>
    <p class="lead text-center">content</p>
</div>
    
@endsection