@extends('layouts/app')
@section('title', 'STE | Focus Groups')

@section('content')
<div id="focus-groups-tile1" class="tile tile-dark-blue">
    <h1 class="text-center">Focus Groups</h1>
    <p class="lead text-center">
        content
    </p>
</div>
    
@endsection