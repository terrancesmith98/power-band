@extends('layouts/app')
@section('title', 'STE | Donate')

@section('content')
<div id="donate-tile1" class="tile-dark-blue tile">
    <h1 class="text-center">Donate to<br> Strength Through Education</h1>
    <p class="text-center lead">content</p>
</div>
    
@endsection