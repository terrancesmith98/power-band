@extends('layouts/app')
@section('title', 'STE | How We Help')

@section('content')
<div id="hwh-tile1" class="tile tile-dark-blue">
    <h1 class="text-center">How We Help</h1>
    <p class="lead">Content</p>
</div>
    
@endsection