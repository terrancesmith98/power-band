@extends('layouts/app')
@section('title', 'STE | Whitepaper')

@section('content')
<div id="whitepaper-tile1" class="tile tile-dark-blue">
    <h1 class="text-center">Our White Papers</h1>
    <p class="lead text-center">
        content
    </p>
</div>
    
@endsection