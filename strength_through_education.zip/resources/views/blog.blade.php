@extends('layouts/app')
@section('title', 'STE | Blog')

@section('content')
<div id="blog-tile1" class="tile tile-dark-blue">
    <h1 class="text-center">Our Blog</h1>
    <p class="lead text-center">
        content
    </p>
</div>
    
@endsection