@extends('layouts/app')
@section('title', 'STE | Newsletter')

@section('content')
<div id="newsletter-tile1" class="tile-dark-blue tile">
    <h1 class="text-center">Sign Up For Our Newsletter</h1>
    <p class="text-center lead">content</p>
</div>
    
@endsection