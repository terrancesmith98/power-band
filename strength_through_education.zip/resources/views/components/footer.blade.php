<footer>
    <p class="text-center">Copyright <?php echo date('Y')?> Strength Through Education. All Rights Reserved.</p>
</footer>