@extends('layouts/app')
@section('title', 'STE | Volunteer')

@section('content')
<div id="volunteer-tile1" class="tile-dark-blue tile">
    <h1 class="text-center">Volunteer With Us</h1>
    <p class="text-center lead">content</p>
</div>
    
@endsection