
<?php $__env->startSection('title', 'STE | How We Help'); ?>

<?php $__env->startSection('content'); ?>
<div id="hwh-tile1" class="tile tile-dark-blue">
    <h1 class="text-center">How We Help</h1>
    <p class="lead">Content</p>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\strength_through_education\resources\views/how-we-help.blade.php ENDPATH**/ ?>