
<?php $__env->startSection('title', 'STE | Blog'); ?>

<?php $__env->startSection('content'); ?>
<div id="blog-tile1" class="tile tile-dark-blue">
    <h1 class="text-center">Our Blog</h1>
    <p class="lead text-center">
        content
    </p>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\strength_through_education\resources\views/blog.blade.php ENDPATH**/ ?>