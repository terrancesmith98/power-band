<footer>
    <p class="text-center">Copyright <?php echo date('Y')?> Strength Through Education. All Rights Reserved.</p>
</footer><?php /**PATH C:\wamp64\www\strength_through_education\resources\views/components/footer.blade.php ENDPATH**/ ?>