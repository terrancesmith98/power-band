
<?php $__env->startSection('title', 'STE | Volunteer'); ?>

<?php $__env->startSection('content'); ?>
<div id="volunteer-tile1" class="tile-dark-blue tile">
    <h1 class="text-center">Volunteer With Us</h1>
    <p class="text-center lead">content</p>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\strength_through_education\resources\views/volunteer.blade.php ENDPATH**/ ?>