<nav class="navbar navbar-expand-md shadow-sm" id="main-nav">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <div class="mr-4">
                <div class="logo">
                    <img src="<?php echo e(asset('images/ste-logo-final.png')); ?>" alt="">
                </div>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto ml-4">
                <li class="nav-item dropdown <?php echo e(request()->routeIs('how-we-help') ? 'active' : ''); ?>">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Programs &amp; Services
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="<?php echo e(route('how-we-help')); ?>">How We Help</a>
                    </div>
                </li>
                <li class="nav-item dropdown <?php echo e(request()->routeIs('donate') || request()->routeIs('volunteer') || request()->routeIs('newsletter') ? 'active' : ''); ?>">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Get Involved
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="<?php echo e(route('donate')); ?>">Donate</a>
                      <a class="dropdown-item" href="<?php echo e(route('volunteer')); ?>">Volunteer</a>
                      <a class="dropdown-item" href="<?php echo e(route('newsletter')); ?>">Newsletter</a>
                    </div>
                </li>
                <li class="nav-item dropdown <?php echo e(request()->routeIs('whitepaper') || request()->routeIs('blog') || request()->routeIs('focus-groups') ? 'active' : ''); ?>">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Our Research
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="<?php echo e(route('whitepaper')); ?>">Whitepaper</a>
                      <a class="dropdown-item" href="<?php echo e(route('blog')); ?>">Blog Posts</a>
                      <a class="dropdown-item" href="<?php echo e(route('focus-groups')); ?>">Focus Groups</a>
                    </div>
                </li>
                <li class="nav-item dropdown <?php echo e(request()->routeIs('who-we-are') || request()->routeIs('our-team') || request()->routeIs('newsroom') || request()->routeIs('faqs') ? 'active' : ''); ?>">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      About Us
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="<?php echo e(route('who-we-are')); ?>">Who Are We</a>
                      <a class="dropdown-item" href="<?php echo e(route('our-team')); ?>">Our Team</a>
                      <a class="dropdown-item" href="<?php echo e(route('newsroom')); ?>">Newsroom</a>
                      <a class="dropdown-item" href="<?php echo e(route('faqs')); ?>">FAQs</a>
                    </div>
                </li>
                <li class="nav-item <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('contact')); ?>" class="nav-link">Contact</a>
                </li>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        
                        
                        

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\wamp64\www\strength_through_education\resources\views/components/navbar.blade.php ENDPATH**/ ?>